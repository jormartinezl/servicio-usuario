package com.mx.springboot.login.usuario.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fasterxml.jackson.databind.JsonMappingException;

import com.fasterxml.jackson.core.JsonParseException;

@ControllerAdvice
public class ErrorHandler {
	
	private static Logger log = LoggerFactory.getLogger(ErrorHandler.class);
	
	@ExceptionHandler({JsonParseException.class, JsonMappingException.class})
	public ResponseEntity<Map<String,Object>> errorJson(Exception ex) {
		Map<String,Object> response = new HashMap<String, Object>();
		response.put("error", "Error en la conversón de JSON");
		response.put("message", ex.getMessage());
		response.put("timestamp", new Date().toString());
		
		log.error(ex.getMessage(), ex);
		return new ResponseEntity<Map<String,Object>> (response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler({IOException.class})
	public ResponseEntity<Map<String,Object>> errorDeArchivo(IOException ex) {
		Map<String,Object> response = new HashMap<String, Object>();
		response.put("error", "Error al cargar el archvo");
		response.put("message", ex.getMessage());
		response.put("timestamp", new Date().toString());
		
		log.error(ex.getMessage(), ex);
		return new ResponseEntity<Map<String,Object>> (response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler({Exception.class})
	public ResponseEntity<Map<String,Object>> errorGeneral(Exception ex) {
		Map<String,Object> response = new HashMap<String, Object>();
		response.put("error", "Ocurrio un error inesperado");
		response.put("message", ex.getMessage());
		response.put("timestamp", new Date().toString());
		
		log.error(ex.getMessage(), ex);
		return new ResponseEntity<Map<String,Object>> (response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
