package com.mx.springboot.login.usuario.models.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mx.springboot.login.usuario.client.IUsuarioClientRest;
import com.mx.springboot.login.usuario.models.Usuario;

@Service
public class ProductoImpService implements IProductoService{
	
	@Autowired
	IUsuarioClientRest clienteRest;
	
	@Override
	public List<Usuario> consultaUsuarios() throws JsonParseException, JsonMappingException, IOException{
		return clienteRest.consultaUsuarios();
	}

}
