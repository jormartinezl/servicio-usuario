package com.mx.springboot.login.usuario.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mx.springboot.login.usuario.models.Usuario;
import com.mx.springboot.login.usuario.models.service.IProductoService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = "/usuario/v1.0")
public class UsuarioController {
	
	private static Logger log = LoggerFactory.getLogger(UsuarioController.class);

	@Autowired
	IProductoService service;
	
	@CrossOrigin(origins = "*")
	@GetMapping("obtenerusuario")
	@ApiOperation(value = "Usuarios logueados",response = Usuario.class,responseContainer = "List")
	public ResponseEntity<Map<String,Object>> obtenerUsario() throws JsonParseException, JsonMappingException, IOException{
		log.info("Comineza proceso obtener usuario");
		Map<String,Object> json= new HashMap<String, Object>();
		List<Usuario> usuarios = service.consultaUsuarios();
		json.put("Usuarios", usuarios);
		json.put("timestamp", new Date().toString());
		log.info("Termina proceso obtener usuario");
		return new ResponseEntity<Map<String,Object>>(json,HttpStatus.OK);
	}

}
