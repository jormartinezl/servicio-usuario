package com.mx.springboot.login.usuario.client;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mx.springboot.login.usuario.models.Usuario;

public interface IUsuarioClientRest {

	public List<Usuario> consultaUsuarios() throws JsonParseException, JsonMappingException, IOException;	
}
