package com.mx.springboot.login.usuario.client;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mx.springboot.login.usuario.models.Usuario;

@Component
public class UsuarioImplClienteRest implements IUsuarioClientRest {

	
	@Value("${ruta.datos}")
	private String ruta;
	@Override
	public List<Usuario> consultaUsuarios() throws JsonParseException, JsonMappingException, IOException {

			ObjectMapper objectMapper = new ObjectMapper();
			
			File s = new File(ruta);
			List<Usuario> listUsuario=null;

			listUsuario = objectMapper.readValue(s, new TypeReference<List<Usuario>>() {});
				

			return listUsuario.stream().map(
					usuarios -> new Usuario(usuarios.getId(), usuarios.getNombreUsuario(), usuarios.getFechaLogueo()))
					.collect(Collectors.toList());

	}
}
