package com.mx.springboot.login.usuario.models;

import java.io.Serializable;
import java.util.Date;

public class Usuario implements Serializable{

	
	private Long id;
	private String nombreUsuario;
	private Date fechaLogueo;
	private String tiempoLogueo;
	

	/**
	 * @param id
	 * @param nombreUsuario
	 * @param fechaLogueo
	 */
	public Usuario(Long id, String nombreUsuario, Date fechaLogueo) {
		this.id = id;
		this.nombreUsuario = nombreUsuario;
		this.fechaLogueo = fechaLogueo;
		
		long fechaInicio=this.fechaLogueo.getTime();
		long fechaActual=new Date().getTime();
		
		this.tiempoLogueo="tiempo de logueo transcurrido: "+ (fechaActual-fechaInicio)/60000 +"min";
	}
	
	
	/**
	 * 
	 */
	public Usuario() {
	}


	private static final long serialVersionUID = 8696395490071109105L;
	
	/**
	 * @return the tiempoLogueo
	 */
	public String getTiempoLogueo() {
		return tiempoLogueo;
	}


	/**
	 * @param tiempoLogueo the tiempoLogueo to set
	 */
	public void setTiempoLogueo(String tiempoLogueo) {
		this.tiempoLogueo = tiempoLogueo;
	}
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the nombreUsuario
	 */
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	/**
	 * @param nombreUsuario the nombreUsuario to set
	 */
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	/**
	 * @return the fechaLogueo
	 */
	public Date getFechaLogueo() {
		return fechaLogueo;
	}
	/**
	 * @param fechaLogueo the fechaLogueo to set
	 */
	public void setFechaLogueo(Date fechaLogueo) {
		this.fechaLogueo = fechaLogueo;
	}
	
	
}
