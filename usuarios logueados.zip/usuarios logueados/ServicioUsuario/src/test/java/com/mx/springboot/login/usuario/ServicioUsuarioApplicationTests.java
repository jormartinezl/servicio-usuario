package com.mx.springboot.login.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
