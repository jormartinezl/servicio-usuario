export interface UsuariosResponse {
    Usuarios:  Usuario[];
    status:    number;
    timestamp: string;
}

export interface Usuario {
    id:            number;
    nombreUsuario: string;
    fechaLogueo:   Date;
    tiempoLogueo:  string;
}