import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UsuariosResponse } from '../interfaces/Usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  constructor(private http:HttpClient) { 
  }

  obtenerUsuarios(){
    return this.http.get<UsuariosResponse>('http://localhost:8080/usuario/v1.0/obtenerusuario');
  }
  
}
